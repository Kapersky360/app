import smtplib
import dns.resolver
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

def read_html_file(file_path):
    with open(file_path, "r") as html_file:
        html_content = html_file.read()
    return html_content

def send_email_batch(server, sender_email, batch, subject, message, to_email, attachment_path):
    try:
        # Créer un objet MIMEMultipart
        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = to_email
        msg['Subject'] = subject

        # Ajouter le contenu HTML du message
        msg.attach(MIMEText(message, 'html'))

        # Si le chemin de la pièce jointe est fourni, ajoutez la pièce jointe
        if attachment_path:
            with open(attachment_path, "rb") as attachment:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(attachment.read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', f"attachment; filename= {attachment_path}")
            msg.attach(part)

        server.sendmail(sender_email, batch, msg.as_string())
        print(f"Batch of {len(batch)} emails successfully sent.")
    except Exception as e:
        print(f"Failed to send email batch: {e}")

def prepare_and_send_batches(recipient_emails, subject, message, sender_email, batch_size, to_email, attachment_path):
    domain = recipient_emails[0].split('@')[1]
    mx_records = dns.resolver.resolve(domain, 'MX')
    mx_record = sorted(mx_records, key=lambda rec: rec.preference)[0]
    mx_server = str(mx_record.exchange).strip('.')

    server = None
    try:
        server = smtplib.SMTP(mx_server)
        server.set_debuglevel(1)  # Activer le débogage pour voir la communication SMTP

        for i in range(0, len(recipient_emails), batch_size):
            batch = recipient_emails[i:i+batch_size]
            send_email_batch(server, sender_email, batch, subject, message, to_email, attachment_path)

            # Fermer la connexion toutes les 500 e-mails
            if (i + batch_size) % 500 == 0:
                server.quit()
                print("Connection closed after sending 500 emails.")
                # Réouvrir la connexion après 500 emails
                server = smtplib.SMTP(mx_server)
                server.set_debuglevel(1)
                
    except Exception as e:
        print(f"Failed to connect to SMTP server: {e}")
    finally:
        if server:
            server.quit()

if __name__ == "__main__":
    sender_email = "supprt<test@television.com>"  # Ajustez au besoin
    subject = "Test"
    message = read_html_file("letter.html")  # Lire le contenu HTML du fichier
    
    with open("list.txt", "r") as file:
        recipient_emails = [line.strip() for line in file.readlines()]
    
    to_email = ""  # Adresse e-mail à ajouter en tant que destinataire "To"
    attachment_path = ""  # Laissez le champ vide si aucune pièce jointe n'est fournie
    
    batch_size = 20  # Taille du lot d'e-mails à envoyer simultanément
    
    prepare_and_send_batches(recipient_emails, subject, message, sender_email, batch_size, to_email, attachment_path)
